# 🤖 Agente Inteligente para Análise de Notas Fiscais - Google Gemini

Uma aplicação avançada que permite fazer consultas em linguagem natural sobre arquivos CSV de notas fiscais do Tribunal de Contas da União, utilizando **Google Gemini API** e **LangChain**.

## 🌟 Características

- ✅ **Interface Web Intuitiva** com Streamlit
- ✅ **Google Gemini API** para processamento de linguagem natural
- ✅ **1.5 bilhão de tokens gratuitos por dia**
- ✅ **Descompactação automática** de arquivos ZIP
- ✅ **Identificação automática** de tipos de arquivo (cabeçalho/itens)
- ✅ **Consultas inteligentes** usando agentes LangChain
- ✅ **Validação de dados** integrada
- ✅ **Dados de exemplo** para teste imediato

## 🚀 Instalação Rápida

### Método 1: Script Automático (Recomendado)

```bash
python install_google.py
```

O script irá:
- Verificar dependências
- Instalar pacotes necessários  
- Configurar Google API Key
- Criar dados de exemplo
- Testar a conexão

### Método 2: Instalação Manual

1. **Clone ou baixe os arquivos**
2. **Instale as dependências:**
   ```bash
   pip install -r requirements_google.txt
   ```
3. **Configure a Google API Key:**
   - Crie arquivo `.env` baseado em `.env.example`
   - Adicione sua API Key: `GOOGLE_API_KEY=sua_chave_aqui`

## 🔑 Como Obter Google API Key

1. Acesse [Google AI Studio](https://ai.google.dev/)
2. Faça login com sua conta Google
3. Clique em **"Get API Key in Google AI Studio"**
4. Crie uma nova API Key
5. Copie a chave gerada

### 💰 Pricing Google Gemini (Gratuito)

- **1.5 bilhão de tokens por dia** (gratuito)
- **15 requisições por minuto** 
- **1.500 requisições por dia**
- **Contexto de até 1 milhão de tokens**

## 🏃‍♂️ Como Executar

```bash
streamlit run main_google.py
```

A aplicação abrirá automaticamente em: `http://localhost:8501`

## 📁 Estrutura de Arquivos

```
projeto/
├── main_google.py              # Aplicação principal (Streamlit)
├── utils_google.py             # Utilitários e validações
├── install_google.py           # Script de instalação automática
├── test_app_google.py          # Gerador de dados de exemplo
├── requirements_google.txt     # Dependências Python
├── .env.example               # Exemplo de configuração
└── exemplo_dados/             # Dados de exemplo (criado automaticamente)
    ├── 202401_NFs_Cabecalho.csv
    ├── 202401_NFs_Itens.csv
    └── notas_fiscais_exemplo.zip
```

## 💬 Exemplos de Consultas

A aplicação responde perguntas como:

- "Qual é o fornecedor que teve maior montante recebido?"
- "Qual item teve maior volume entregue (em quantidade)?"
- "Quantas notas fiscais foram emitidas no total?"
- "Qual é a soma total de todos os valores das notas fiscais?"
- "Quais são os 5 fornecedores com maior valor total?"
- "Qual é a média de valor por item?"
- "Quantos itens diferentes foram comprados?"
- "Qual é o produto mais caro?"
- "Em que período foram emitidas as notas fiscais?"
- "Qual é a distribuição de valores por fornecedor?"

## 🔧 Configuração Avançada

### Variáveis de Ambiente (.env)

```env
# Google API Configuration
GOOGLE_API_KEY=sua_google_api_key_aqui

# Opcional: Configurações do modelo
GEMINI_MODEL=gemini-1.5-flash
GEMINI_TEMPERATURE=0.1

# Configurações da aplicação
APP_TITLE=Agente de Análise de Notas Fiscais
APP_ICON=📊
```

### Modelos Disponíveis

- `gemini-1.5-flash` (recomendado - rápido e eficiente)
- `gemini-1.5-pro` (mais avançado, menor limite gratuito)
- `gemini-2.0-flash` (mais recente)

## 📊 Formato dos Dados

### Arquivo de Cabeçalho (202401_NFs_Cabecalho.csv)
```csv
numero,serie,data_emissao,cnpj_fornecedor,nome_fornecedor,valor_total,...
000001,001,2024-01-15 14:30:25,12.345.678/0001-90,Tech Solutions Ltda,2847.50,...
```

### Arquivo de Itens (202401_NFs_Itens.csv)
```csv
numero_nf,item,codigo_produto,descricao,quantidade,unidade,valor_unitario,valor_total,...
000001,001,COMP001,Computador Desktop Core i7,1,UN,2500.00,2500.00,...
```

## 🛠️ Tecnologias Utilizadas

- **[Google Gemini API](https://ai.google.dev/)** - Modelo de linguagem natural
- **[LangChain](https://python.langchain.com/)** - Framework para aplicações IA
- **[Streamlit](https://streamlit.io/)** - Interface web
- **[Pandas](https://pandas.pydata.org/)** - Manipulação de dados
- **Python 3.8+** - Linguagem base

## 🔍 Solução de Problemas

### Erro: "Google API Key não encontrada"
- Verifique se a API Key está configurada no arquivo `.env`
- Certifique-se que a variável se chama exatamente `GOOGLE_API_KEY`

### Erro: "Erro ao criar modelo Gemini"
- Verifique se sua API Key está válida
- Confirme se tem créditos/cota disponível na Google AI
- Teste a conexão em https://ai.google.dev/

### Erro: "Arquivo ZIP inválido"
- Certifique-se que o arquivo ZIP contém CSVs válidos
- Verifique se os CSVs seguem o formato esperado

### Performance lenta
- Use o modelo `gemini-1.5-flash` para consultas mais rápidas
- Reduza a temperatura para respostas mais determinísticas
- Considere o limite de 15 RPM do tier gratuito

## 📈 Melhorias Futuras

- [ ] Suporte a múltiplos formatos (Excel, JSON)
- [ ] Dashboard de visualizações
- [ ] Cache de consultas
- [ ] API REST
- [ ] Autenticação de usuários
- [ ] Histórico de consultas
- [ ] Exportação de relatórios

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## 🔗 Links Úteis

- [Google AI Studio](https://ai.google.dev/)
- [LangChain Documentation](https://python.langchain.com/)
- [Streamlit Documentation](https://docs.streamlit.io/)
- [Tribunal de Contas da União](https://portal.tcu.gov.br/)

## ⚠️ Importante

- **Mantenha sua Google API Key segura** - nunca compartilhe ou commite no código
- **Respeite os limites** da API gratuita
- **Dados sensíveis** devem ser tratados conforme LGPD
- **Sempre valide** os resultados das consultas

---

Desenvolvido com ❤️ usando Google Gemini API & LangChain