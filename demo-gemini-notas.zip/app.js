// App state
let currentSection = 'home';
let uploadedData = null;
let queryHistory = [];
let isProcessingQuery = false;

// Sample data from the application_data_json
const sampleData = {
  consultas: [
    {
      pergunta: "Qual é o fornecedor que teve maior montante recebido?",
      resposta: "Com base na análise dos dados carregados, o fornecedor que teve o maior montante recebido foi **Tech Solutions Ltda** (CNPJ: 12.345.678/0001-90) com um valor total de **R$ 45.750,00**, representando 18.3% do valor total das notas fiscais processadas."
    },
    {
      pergunta: "Qual item teve maior volume entregue (em quantidade)?",
      resposta: "O item com maior volume entregue foi **Papel A4 500 folhas** (código PAP001) com um total de **2.450 unidades** distribuídas em 35 notas fiscais diferentes, seguido por **Mouse Óptico** com 1.890 unidades."
    },
    {
      pergunta: "Quantas notas fiscais foram emitidas no total?",
      resposta: "Foram processadas **100 notas fiscais** no período de janeiro/2024, todas extraídas do arquivo ZIP fornecido. Dessas, 97 estão com situação 'Normal', 2 foram 'Canceladas' e 1 está 'Autorizada'."
    },
    {
      pergunta: "Qual é a soma total de todos os valores das notas fiscais?",
      resposta: "O valor total de todas as notas fiscais processadas é de **R$ 249.847,50**. Este valor inclui produtos, descontos aplicados e acréscimos, conforme registrado nos cabeçalhos das notas fiscais."
    },
    {
      pergunta: "Quais são os 5 fornecedores com maior valor total?",
      resposta: "Os 5 fornecedores com maior valor total são:\n\n1. **Tech Solutions Ltda**: R$ 45.750,00\n2. **Suprimentos Industriais S.A.**: R$ 38.920,00\n3. **Equipamentos Profissionais Ltda**: R$ 31.240,00\n4. **Distribuidora Nacional**: R$ 28.850,00\n5. **Produtos Especializados S.A.**: R$ 25.100,00"
    }
  ],
  cabecalho: [
    {
      numero: "000001",
      serie: "001",
      data_emissao: "2024-01-15",
      cnpj_fornecedor: "12.345.678/0001-90",
      nome_fornecedor: "Tech Solutions Ltda",
      valor_total: 2847.50
    },
    {
      numero: "000002",
      serie: "001",
      data_emissao: "2024-01-16",
      cnpj_fornecedor: "98.765.432/0001-10",
      nome_fornecedor: "Suprimentos Industriais S.A.",
      valor_total: 1890.75
    },
    {
      numero: "000003",
      serie: "002",
      data_emissao: "2024-01-16",
      cnpj_fornecedor: "11.222.333/0001-44",
      nome_fornecedor: "Materiais de Escritório Express",
      valor_total: 3250.00
    },
    {
      numero: "000004",
      serie: "001",
      data_emissao: "2024-01-17",
      cnpj_fornecedor: "22.333.444/0001-55",
      nome_fornecedor: "Equipamentos Profissionais Ltda",
      valor_total: 4150.25
    },
    {
      numero: "000005",
      serie: "003",
      data_emissao: "2024-01-18",
      cnpj_fornecedor: "33.444.555/0001-66",
      nome_fornecedor: "Distribuidora Nacional",
      valor_total: 2680.00
    }
  ]
};

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
  // Set up navigation
  const navButtons = document.querySelectorAll('.nav__btn');
  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const section = btn.dataset.section;
      showSection(section);
      updateActiveNavButton(btn);
    });
  });
  
  // Set up upload zone
  const uploadZone = document.getElementById('uploadZone');
  const fileInput = document.getElementById('fileInput');
  
  if (uploadZone && fileInput) {
    uploadZone.addEventListener('click', () => fileInput.click());
    
    uploadZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      uploadZone.classList.add('upload-zone--active');
    });
    
    uploadZone.addEventListener('dragleave', (e) => {
      e.preventDefault();
      uploadZone.classList.remove('upload-zone--active');
    });
    
    uploadZone.addEventListener('drop', (e) => {
      e.preventDefault();
      uploadZone.classList.remove('upload-zone--active');
      simulateUpload();
    });
    
    fileInput.addEventListener('change', () => {
      if (fileInput.files.length > 0) simulateUpload();
    });
  }
  
  // Set up query input
  const queryInput = document.getElementById('queryInput');
  if (queryInput) {
    queryInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter' && e.ctrlKey) submitQuery();
    });
  }
  
  // Set up event handlers for modal close
  document.addEventListener('click', (e) => {
    const modal = document.getElementById('modal');
    if (e.target === modal) closeModal();
  });
  
  // Set up keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeModal();
      hideLoadingOverlay();
    }
    
    if (e.altKey) {
      switch(e.key) {
        case '1': activateSection('home'); break;
        case '2': activateSection('upload'); break;
        case '3': activateSection('consultas'); break;
        case '4': activateSection('config'); break;
      }
    }
  });
  
  // Show initial section
  showSection('home');
  
  // Animate stats on homepage
  setTimeout(() => animateHomeStats(), 500);
});

function activateSection(sectionId) {
  showSection(sectionId);
  const navBtn = document.querySelector(`[data-section="${sectionId}"]`);
  if (navBtn) updateActiveNavButton(navBtn);
}

function showSection(sectionId) {
  // Hide all sections
  document.querySelectorAll('.section').forEach(section => {
    section.classList.remove('section--active');
  });
  
  // Show selected section
  const targetSection = document.getElementById(sectionId);
  if (targetSection) {
    targetSection.classList.add('section--active');
    currentSection = sectionId;
  }
}

function updateActiveNavButton(activeBtn) {
  document.querySelectorAll('.nav__btn').forEach(btn => {
    btn.classList.remove('nav__btn--active');
  });
  activeBtn.classList.add('nav__btn--active');
}

function animateHomeStats() {
  const statNumbers = document.querySelectorAll('.stat-number');
  statNumbers.forEach((stat, index) => {
    setTimeout(() => {
      if (stat) {
        stat.style.transition = 'transform 0.2s ease';
        stat.style.transform = 'scale(1.1)';
        setTimeout(() => {
          stat.style.transform = 'scale(1)';
        }, 200);
      }
    }, index * 100);
  });
}

// Upload functions
function simulateUpload() {
  const uploadResults = document.getElementById('uploadResults');
  const progressFill = document.getElementById('progressFill');
  const progressText = document.getElementById('progressText');
  
  if (!uploadResults || !progressFill || !progressText) return;
  
  // Show upload results
  uploadResults.classList.remove('hidden');
  
  // Reset progress
  progressFill.style.width = '0%';
  progressText.textContent = 'Iniciando processamento...';
  
  // Simulate progress
  let progress = 0;
  const progressInterval = setInterval(() => {
    progress += Math.random() * 15 + 5;
    
    if (progress >= 100) {
      progress = 100;
      clearInterval(progressInterval);
      progressText.textContent = 'Processamento concluído! ✅';
      
      setTimeout(() => {
        populateDataTable();
      }, 300);
    } else {
      progressText.textContent = `Processando arquivos... ${Math.round(progress)}%`;
    }
    
    progressFill.style.width = progress + '%';
  }, 400);
  
  uploadedData = sampleData.cabecalho;
}

function populateDataTable() {
  const dataTableBody = document.getElementById('dataTableBody');
  if (!dataTableBody) return;
  
  dataTableBody.innerHTML = '';
  
  sampleData.cabecalho.forEach(item => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${item.numero}</td>
      <td>${formatDate(item.data_emissao)}</td>
      <td>${item.nome_fornecedor}</td>
      <td>${formatCurrency(item.valor_total)}</td>
    `;
    dataTableBody.appendChild(row);
  });
}

function clearUpload() {
  const uploadResults = document.getElementById('uploadResults');
  const progressFill = document.getElementById('progressFill');
  const progressText = document.getElementById('progressText');
  const fileInput = document.getElementById('fileInput');
  
  if (uploadResults) uploadResults.classList.add('hidden');
  if (progressFill) progressFill.style.width = '0%';
  if (progressText) progressText.textContent = 'Processando...';
  if (fileInput) fileInput.value = '';
  
  uploadedData = null;
}

// Query functions
function submitQuery() {
  if (isProcessingQuery) return;
  
  const queryInput = document.getElementById('queryInput');
  if (!queryInput) return;
  
  const question = queryInput.value.trim();
  
  if (!question) {
    alert('Por favor, digite uma pergunta.');
    return;
  }
  
  // Disable further submissions during processing
  isProcessingQuery = true;
  
  // Show loading and disable input
  const loadingOverlay = document.getElementById('loadingOverlay');
  if (loadingOverlay) loadingOverlay.classList.remove('hidden');
  
  queryInput.disabled = true;
  
  // Process the query with a timeout
  setTimeout(() => {
    try {
      const answer = findMatchingAnswer(question);
      addQueryToHistory(question, answer);
      queryInput.value = '';
    } catch (error) {
      console.error('Error processing query:', error);
      addQueryToHistory(question, 'Erro ao processar consulta. Tente novamente.');
    } finally {
      // Always ensure the overlay is hidden and input is re-enabled
      if (loadingOverlay) loadingOverlay.classList.add('hidden');
      queryInput.disabled = false;
      queryInput.focus();
      isProcessingQuery = false;
    }
  }, 1500);
}

function findMatchingAnswer(question) {
  const lowerQuestion = question.toLowerCase();
  
  // Check for keyword matches
  for (const consulta of sampleData.consultas) {
    const keywords = consulta.pergunta.toLowerCase();
    
    if ((lowerQuestion.includes('fornecedor') && lowerQuestion.includes('maior')) ||
        (lowerQuestion.includes('montante') && keywords.includes('fornecedor'))) {
      return consulta.resposta;
    }
    
    if ((lowerQuestion.includes('item') && lowerQuestion.includes('volume')) ||
        (lowerQuestion.includes('quantidade') && keywords.includes('volume'))) {
      return consulta.resposta;
    }
    
    if ((lowerQuestion.includes('quantas') && lowerQuestion.includes('notas')) ||
        (lowerQuestion.includes('total') && lowerQuestion.includes('emitidas'))) {
      return consulta.resposta;
    }
    
    if ((lowerQuestion.includes('soma') && lowerQuestion.includes('total')) ||
        (lowerQuestion.includes('valor') && lowerQuestion.includes('total'))) {
      return consulta.resposta;
    }
    
    if (lowerQuestion.includes('top') || lowerQuestion.includes('5') ||
        (lowerQuestion.includes('cinco') && lowerQuestion.includes('fornecedor'))) {
      return consulta.resposta;
    }
  }
  
  // Default response for unmatched queries
  return `Baseado nos dados carregados, posso ajudá-lo com informações sobre as 100 notas fiscais processadas. 

**Sua pergunta:** "${question}"

Para esta demonstração, tenho respostas específicas para consultas sobre:
- Fornecedores com maior montante
- Itens com maior volume
- Quantidade total de notas
- Valor total das transações
- Ranking de fornecedores

**Estatísticas gerais:**
- Total de notas: 100
- Valor total: R$ 249.847,50
- Fornecedores únicos: 10
- Período: Janeiro/2024

Experimente as perguntas de exemplo para ver respostas mais detalhadas! 🤖`;
}

function useExampleQuery(index) {
  const queryInput = document.getElementById('queryInput');
  if (queryInput && sampleData.consultas[index]) {
    queryInput.value = sampleData.consultas[index].pergunta;
    queryInput.focus();
  }
}

function addQueryToHistory(question, answer) {
  const queryHistory = document.getElementById('queryHistory');
  if (!queryHistory) return;
  
  const timestamp = new Date().toLocaleString('pt-BR');
  
  const queryItem = document.createElement('div');
  queryItem.className = 'query-item card';
  queryItem.innerHTML = `
    <div class="query-question">
      🤔 ${question}
    </div>
    <div class="query-answer">
      🤖 ${answer}
      <div class="query-timestamp">${timestamp}</div>
    </div>
  `;
  
  queryHistory.insertBefore(queryItem, queryHistory.firstChild);
  
  // Limit to 10 queries in history
  while (queryHistory.children.length > 10) {
    queryHistory.removeChild(queryHistory.lastChild);
  }
}

function clearQuery() {
  const queryInput = document.getElementById('queryInput');
  if (queryInput) {
    queryInput.value = '';
    queryInput.focus();
  }
}

// Configuration functions
function showApiInfo() {
  const modal = document.getElementById('modal');
  const modalTitle = document.getElementById('modalTitle');
  const modalBody = document.getElementById('modalBody');
  
  if (!modal || !modalTitle || !modalBody) return;
  
  modalTitle.textContent = '📊 Informações do Google Gemini API';
  modalBody.innerHTML = `
    <div style="line-height: 1.6;">
      <h4>🚀 Recursos Principais</h4>
      <ul>
        <li><strong>1.5 bilhão de tokens gratuitos por dia</strong></li>
        <li><strong>Processamento de linguagem natural avançado</strong></li>
        <li><strong>Suporte a múltiplos formatos de entrada</strong></li>
        <li><strong>Integração simples com Python</strong></li>
        <li><strong>Respostas contextuais e inteligentes</strong></li>
      </ul>
      
      <h4>💰 Preços</h4>
      <p><strong>Gratuito:</strong> 15 requisições por minuto, 1500 por dia<br>
      <strong>Pago:</strong> 360 requisições por minuto, sem limite diário</p>
      
      <h4>🔧 Como usar</h4>
      <ol>
        <li>Obtenha sua API key em <a href="https://makersuite.google.com/" target="_blank">Google AI Studio</a></li>
        <li>Instale o SDK: <code>pip install google-generativeai</code></li>
        <li>Configure sua chave e comece a usar!</li>
      </ol>
      
      <h4>📚 Documentação</h4>
      <p>Acesse a <a href="https://ai.google.dev/" target="_blank">documentação oficial</a> para mais detalhes.</p>
    </div>
  `;
  
  showModal();
}

// Modal functions
function showModal() {
  const modal = document.getElementById('modal');
  if (modal) {
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal() {
  const modal = document.getElementById('modal');
  if (modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

// Loading overlay functions
function hideLoadingOverlay() {
  const overlay = document.getElementById('loadingOverlay');
  if (overlay) {
    overlay.classList.add('hidden');
  }
  isProcessingQuery = false;
}

// Utility functions
function formatCurrency(value) {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
}

function formatDate(dateString) {
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
  } catch (e) {
    return dateString;
  }
}