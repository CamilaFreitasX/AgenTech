import streamlit as st
import pandas as pd
import zipfile
import os
import tempfile
from io import StringIO
from langchain_experimental.agents import create_csv_agent
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.agents.agent_types import AgentType
from utils import NotaFiscalValidator, extract_zip_file
import warnings
warnings.filterwarnings("ignore")

class CSVAnalysisAgent:
    def __init__(self, google_api_key=None):
        """Inicializa o agente de análise CSV com Google Gemini"""
        self.google_api_key = google_api_key
        self.agents = {}
        self.dataframes = {}
        self.file_info = {}
        
    def create_llm(self):
        """Cria uma instância do modelo Google Gemini"""
        if not self.google_api_key:
            raise ValueError("Google API Key é necessária para usar o agente")
        
        try:
            llm = ChatGoogleGenerativeAI(
                model="gemini-1.5-flash",
                google_api_key=self.google_api_key,
                temperature=0.1,
                convert_system_message_to_human=True
            )
            return llm
        except Exception as e:
            st.error(f"Erro ao criar modelo Gemini: {str(e)}")
            return None
    
    def load_csv_data(self, file_path, file_type):
        """Carrega dados CSV e cria agente específico"""
        try:
            # Lê o arquivo CSV
            df = pd.read_csv(file_path, encoding='utf-8')
            
            # Armazena o dataframe
            self.dataframes[file_type] = df
            self.file_info[file_type] = {
                'path': file_path,
                'shape': df.shape,
                'columns': df.columns.tolist()
            }
            
            # Cria o LLM
            llm = self.create_llm()
            if llm is None:
                return False
            
            # Cria agente específico para este CSV
            agent = create_csv_agent(
                llm,
                file_path,
                verbose=True,
                agent_type=AgentType.OPENAI_FUNCTIONS,
                allow_dangerous_code=True,
                handle_parsing_errors=True
            )
            
            self.agents[file_type] = agent
            return True
            
        except Exception as e:
            st.error(f"Erro ao carregar arquivo {file_type}: {str(e)}")
            return False
    
    def create_general_agent(self):
        """Cria um agente geral que pode consultar todos os arquivos"""
        try:
            if not self.dataframes:
                return None
            
            llm = self.create_llm()
            if llm is None:
                return None
            
            # Lista de caminhos dos arquivos
            file_paths = [info['path'] for info in self.file_info.values()]
            
            # Cria agente para múltiplos CSVs
            general_agent = create_csv_agent(
                llm,
                file_paths,
                verbose=True,
                agent_type=AgentType.OPENAI_FUNCTIONS,
                allow_dangerous_code=True,
                handle_parsing_errors=True
            )
            
            return general_agent
            
        except Exception as e:
            st.error(f"Erro ao criar agente geral: {str(e)}")
            return None
    
    def query(self, question, agent_type="geral"):
        """Executa uma consulta usando o agente especificado"""
        try:
            if agent_type == "geral":
                agent = self.create_general_agent()
                if agent is None:
                    return "Erro: Não foi possível criar o agente geral."
            else:
                agent = self.agents.get(agent_type)
                if agent is None:
                    return f"Erro: Agente para {agent_type} não encontrado."
            
            # Executa a consulta
            response = agent.invoke({"input": question})
            return response.get("output", "Não foi possível gerar uma resposta.")
            
        except Exception as e:
            return f"Erro ao processar consulta: {str(e)}"
    
    def get_data_summary(self):
        """Retorna um resumo dos dados carregados"""
        summary = {}
        for file_type, df in self.dataframes.items():
            summary[file_type] = {
                'linhas': len(df),
                'colunas': len(df.columns),
                'colunas_lista': df.columns.tolist(),
                'tipos': df.dtypes.to_dict(),
                'primeiras_linhas': df.head().to_dict('records')
            }
        return summary

def main():
    st.set_page_config(
        page_title="Agente de Análise de Notas Fiscais - Google Gemini",
        page_icon="📊",
        layout="wide"
    )
    
    st.title("🤖 Agente Inteligente para Análise de Notas Fiscais")
    st.markdown("### Powered by Google Gemini API & LangChain")
    st.markdown("---")
    
    # Configuração da API Key
    st.sidebar.header("⚙️ Configurações")
    
    # Tenta carregar a API key de diferentes fontes
    google_api_key = None
    
    # 1. Variável de ambiente
    if os.getenv("GOOGLE_API_KEY"):
        google_api_key = os.getenv("GOOGLE_API_KEY")
        st.sidebar.success("✅ API Key carregada das variáveis de ambiente")
    
    # 2. Arquivo .env (se existir)
    elif os.path.exists(".env"):
        try:
            with open(".env", "r") as f:
                for line in f:
                    if line.startswith("GOOGLE_API_KEY="):
                        google_api_key = line.split("=", 1)[1].strip()
                        st.sidebar.success("✅ API Key carregada do arquivo .env")
                        break
        except:
            pass
    
    # 3. Input do usuário
    if not google_api_key:
        google_api_key = st.sidebar.text_input(
            "Google API Key",
            type="password",
            help="Insira sua Google API Key. Você pode obtê-la em https://ai.google.dev/"
        )
    
    if not google_api_key:
        st.warning("⚠️ Por favor, configure sua Google API Key para usar o agente.")
        st.markdown("""
        ### Como obter sua Google API Key:
        1. Acesse [Google AI Studio](https://ai.google.dev/)
        2. Faça login com sua conta Google
        3. Clique em "Get API Key"
        4. Crie uma nova API Key
        5. Copie e cole a chave acima
        
        ### Características do Google Gemini:
        - **1.5 bilhão de tokens gratuitos por dia**
        - **15 requisições por minuto (gratuito)**
        - **Suporte a múltiplas modalidades**
        - **Modelos avançados (Gemini 1.5 Flash)**
        """)
        return
    
    # Inicializa o agente
    if 'csv_agent' not in st.session_state:
        st.session_state.csv_agent = CSVAnalysisAgent(google_api_key)
    
    # Upload de arquivos
    st.header("📁 Upload de Arquivos")
    uploaded_file = st.file_uploader(
        "Faça upload do arquivo ZIP contendo os CSVs de notas fiscais",
        type=['zip'],
        help="Upload do arquivo ZIP contendo os arquivos CSV das notas fiscais"
    )
    
    if uploaded_file is not None:
        with st.spinner("Processando arquivos..."):
            # Extrai o arquivo ZIP
            temp_dir = extract_zip_file(uploaded_file)
            
            if temp_dir:
                st.success("✅ Arquivo ZIP extraído com sucesso!")
                
                # Processa os arquivos CSV
                validator = NotaFiscalValidator()
                csv_files = [f for f in os.listdir(temp_dir) if f.endswith('.csv')]
                
                loaded_files = []
                for csv_file in csv_files:
                    file_path = os.path.join(temp_dir, csv_file)
                    file_type = validator.identify_file_type(file_path)
                    
                    if file_type != "unknown":
                        success = st.session_state.csv_agent.load_csv_data(file_path, file_type)
                        if success:
                            loaded_files.append(f"{csv_file} ({file_type})")
                
                if loaded_files:
                    st.success(f"✅ Arquivos carregados: {', '.join(loaded_files)}")
                    
                    # Mostra resumo dos dados
                    with st.expander("📊 Resumo dos Dados Carregados"):
                        summary = st.session_state.csv_agent.get_data_summary()
                        for file_type, info in summary.items():
                            st.subheader(f"📄 {file_type.title()}")
                            col1, col2 = st.columns(2)
                            with col1:
                                st.metric("Linhas", info['linhas'])
                                st.metric("Colunas", info['colunas'])
                            with col2:
                                st.write("**Colunas:**")
                                st.write(", ".join(info['colunas_lista']))
                            
                            # Mostra primeiras linhas
                            if st.checkbox(f"Ver primeiras linhas - {file_type}", key=f"show_{file_type}"):
                                df_display = pd.DataFrame(info['primeiras_linhas'])
                                st.dataframe(df_display, use_container_width=True)
    
    # Interface de consultas
    if hasattr(st.session_state, 'csv_agent') and st.session_state.csv_agent.dataframes:
        st.header("🔍 Faça suas perguntas")
        
        # Exemplos de perguntas
        with st.expander("💡 Exemplos de Perguntas"):
            st.markdown("""
            - Qual é o fornecedor que teve maior montante recebido?
            - Qual item teve maior volume entregue (em quantidade)?
            - Quantas notas fiscais foram emitidas no total?
            - Qual é a soma total de todos os valores das notas fiscais?
            - Quais são os 5 fornecedores com maior valor total?
            - Qual é a média de valor por item?
            - Quantos itens diferentes foram comprados?
            - Qual é o produto mais caro?
            - Em que período foram emitidas as notas fiscais?
            - Qual é a distribuição de valores por fornecedor?
            """)
        
        # Campo de pergunta
        user_question = st.text_area(
            "Digite sua pergunta sobre os dados:",
            placeholder="Ex: Qual é o fornecedor que teve maior montante recebido?",
            height=100
        )
        
        col1, col2 = st.columns([1, 4])
        with col1:
            agent_type = st.selectbox(
                "Agente:",
                ["geral"] + list(st.session_state.csv_agent.agents.keys()),
                help="Escolha qual agente usar para a consulta"
            )
        
        if st.button("🚀 Executar Consulta", type="primary"):
            if user_question.strip():
                with st.spinner("Processando consulta..."):
                    response = st.session_state.csv_agent.query(user_question, agent_type)
                    
                    st.markdown("### 📋 Resposta:")
                    st.markdown(response)
            else:
                st.warning("⚠️ Por favor, digite uma pergunta.")
    
    # Informações adicionais
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 📚 Sobre")
    st.sidebar.markdown("""
    Esta aplicação utiliza:
    - **Google Gemini API** para processamento de linguagem natural
    - **LangChain** para criação de agentes inteligentes
    - **Streamlit** para interface web
    - **Pandas** para manipulação de dados
    """)
    
    st.sidebar.markdown("### 🔗 Links Úteis")
    st.sidebar.markdown("""
    - [Google AI Studio](https://ai.google.dev/)
    - [LangChain Documentation](https://python.langchain.com/)
    - [Streamlit Documentation](https://docs.streamlit.io/)
    """)

if __name__ == "__main__":
    main()